"""Credentials stay server-side, encrypted with the existing deployment secret."""
import base64, hashlib, hmac
from cryptography.fernet import Fernet
from auth import JWT_SECRET

def cipher():
    key = hmac.new(JWT_SECRET.encode(), b'rsvx7-remote-control-v1', hashlib.sha256).digest()
    return Fernet(base64.urlsafe_b64encode(key))
def encrypt(value): return cipher().encrypt(value.encode()).decode() if value else None
def decrypt(value): return cipher().decrypt(value.encode()).decode() if value else None
