"""Resumable chat streams: generation runs in a background task, clients follow by event offset."""
import asyncio
import time
import uuid

_STREAMS: dict[str, dict] = {}
_RETENTION_SECONDS = 600


def _sweep():
    cutoff = time.monotonic() - _RETENTION_SECONDS
    for sid in [k for k, v in _STREAMS.items() if v["done"] and v["finished_at"] < cutoff]:
        _STREAMS.pop(sid, None)


def start_stream(user_id: str, source, first_event) -> str:
    """Begin consuming `source` in the background; `first_event(sid)` is stored as event 0."""
    _sweep()
    sid = uuid.uuid4().hex
    state = {"user": user_id, "events": [first_event(sid)], "done": False, "finished_at": 0.0,
             "cond": asyncio.Condition(), "task": None}
    _STREAMS[sid] = state

    async def pump():
        try:
            async for event in source:
                async with state["cond"]:
                    state["events"].append(event)
                    state["cond"].notify_all()
        finally:
            async with state["cond"]:
                state["done"] = True
                state["finished_at"] = time.monotonic()
                state["cond"].notify_all()

    state["task"] = asyncio.create_task(pump(), name="rsvx7-chat-stream-" + sid)
    return sid


def get_stream(sid: str, user_id: str):
    state = _STREAMS.get(sid)
    return state if state and state["user"] == user_id else None


async def follow(state: dict, offset: int = 0):
    index = max(0, offset)
    while True:
        async with state["cond"]:
            while index >= len(state["events"]) and not state["done"]:
                await state["cond"].wait()
            batch = state["events"][index:]
            done = state["done"]
        for event in batch:
            yield event
        index += len(batch)
        if done and index >= len(state["events"]):
            return


def cancel_stream(state: dict) -> bool:
    task = state.get("task")
    if task and not task.done():
        task.cancel()
        return True
    return False
