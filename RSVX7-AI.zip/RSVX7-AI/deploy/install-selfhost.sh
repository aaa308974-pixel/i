#!/bin/sh
set -eu
DEPLOY_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
RSVX7_SELFHOST_ENV="$(realpath "${1:-$DEPLOY_DIR/../.env.selfhost}")"
export RSVX7_SELFHOST_ENV
RSVX7_RELEASE_ID="${RSVX7_RELEASE_ID:-$(basename "$(dirname "$DEPLOY_DIR")")}"
export RSVX7_RELEASE_ID
command -v docker >/dev/null 2>&1 || { echo 'Docker is required.' >&2; exit 1; }
docker compose version >/dev/null
# dotenv is parsed by Compose, never sourced as shell code.
RSVX7_MODEL_MODE="$(python3 -c 'import pathlib,sys;v=dict(x.split("=",1) for x in pathlib.Path(sys.argv[1]).read_text().splitlines() if "=" in x);print(v.get("AI_PROVIDER","openrouter"))' "$RSVX7_SELFHOST_ENV")"
compose() { if [ "$RSVX7_MODEL_MODE" = local ]; then docker compose -p rsvx7 --env-file "$RSVX7_SELFHOST_ENV" -f "$DEPLOY_DIR/compose.selfhost.yaml" --profile local "$@"; else docker compose -p rsvx7 --env-file "$RSVX7_SELFHOST_ENV" -f "$DEPLOY_DIR/compose.selfhost.yaml" "$@"; fi; }
echo 'RSVX7_STAGE:building'
compose build app
echo 'RSVX7_STAGE:starting'
compose up -d
if [ "$RSVX7_MODEL_MODE" = local ]; then
  echo 'RSVX7_STAGE:model'
  RSVX7_LOCAL_MODEL="$(python3 -c 'import pathlib,sys;v=dict(x.split("=",1) for x in pathlib.Path(sys.argv[1]).read_text().splitlines() if "=" in x);print(v["LOCAL_MODEL_NAME"])' "$RSVX7_SELFHOST_ENV")"
  compose exec -T ollama ollama pull "$RSVX7_LOCAL_MODEL"
fi
echo 'RSVX7_STAGE:checking'
RSVX7_ATTEMPT=0
until compose exec -T app python -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:3000/readyz",timeout=4);r=urllib.request.urlopen("http://127.0.0.1:3000/",timeout=4);assert r.status==200' >/dev/null 2>&1; do
  RSVX7_ATTEMPT=$((RSVX7_ATTEMPT+1)); [ "$RSVX7_ATTEMPT" -lt 60 ] || { echo 'Application readiness failed.' >&2; exit 1; }
  sleep 5
done
echo 'RSVX7_STAGE:ready'
