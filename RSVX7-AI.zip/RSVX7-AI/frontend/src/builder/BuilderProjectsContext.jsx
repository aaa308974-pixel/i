import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from '@/context/AuthContext';

const BuilderProjectsContext = createContext(null);

export function BuilderProjectsProvider({ children }) {
  const { authFetch, user } = useAuth();
  const key = 'rsvx7_builder_active_' + (user?._id || 'anon');
  const [projects, setProjects] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const activeRef = useRef(null);
  const call = useCallback(async (path = '', options = {}) => {
    const response = await authFetch('/builder/projects' + path, options);
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'تعذّر إكمال الطلب.');
    return result;
  }, [authFetch]);
  const select = useCallback((id) => {
    activeRef.current = id; setActiveId(id);
    try { if (id) localStorage.setItem(key, id); else localStorage.removeItem(key); } catch {}
  }, [key]);
  const refresh = useCallback(async () => {
    const list = await call();
    setProjects(list); setLoading(false);
    return list;
  }, [call]);
  useEffect(() => {
    if (!user?._id) return;
    let stored = null;
    try { stored = localStorage.getItem(key); } catch {}
    setLoading(true);
    refresh().then((list) => select(list.some((p) => p._id === stored) ? stored : list[0]?._id || null)).catch(() => setLoading(false));
  }, [user?._id, key, refresh, select]);
  const create = useCallback(async (name = '') => {
    const project = await call('', { method: 'POST', body: JSON.stringify({ name }) });
    setProjects((prev) => [project, ...prev]); select(project._id);
    return project;
  }, [call, select]);
  const rename = useCallback(async (id, name) => {
    await call('/' + encodeURIComponent(id), { method: 'PATCH', body: JSON.stringify({ name }) });
    setProjects((prev) => prev.map((p) => p._id === id ? { ...p, name } : p));
  }, [call]);
  const remove = useCallback(async (id) => {
    await call('/' + encodeURIComponent(id), { method: 'DELETE' });
    setProjects((prev) => {
      const next = prev.filter((p) => p._id !== id);
      if (activeRef.current === id) select(next[0]?._id || null);
      return next;
    });
  }, [call, select]);
  const value = useMemo(() => ({ projects, activeId, loading, select, create, rename, remove, refresh }), [projects, activeId, loading, select, create, rename, remove, refresh]);
  return <BuilderProjectsContext.Provider value={value}>{children}</BuilderProjectsContext.Provider>;
}

export const useBuilderProjects = () => useContext(BuilderProjectsContext);
