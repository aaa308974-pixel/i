import React, { useState } from "react";
import { Eye, EyeOff, LogOut, ShieldCheck } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, AuthShell, Panel, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

function PasswordField({ id, testId, label, value, onChange, autoComplete }) {
  const { t } = useI18n("auth");
  const [visible, setVisible] = useState(false);
  return (
    <div className="ds-field auth-ui-field">
      <label className="auth-ui-label" htmlFor={id}>{t(label)}</label>
      <div className="auth-ui-input-wrap has-toggle">
        <input id={id} data-testid={testId} className="ds-input auth-ui-input" type={visible ? "text" : "password"} value={value} onChange={onChange} autoComplete={autoComplete} placeholder={t(label)} required minLength={6} />
        <button type="button" className="auth-ui-toggle" onClick={() => setVisible((current) => !current)} aria-label={visible ? t("إخفاء كلمة المرور") : t("إظهار كلمة المرور")} aria-pressed={visible} data-testid={`${testId}-toggle`}>
          {visible ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
        </button>
      </div>
    </div>
  );
}

export default function ForcePasswordChange() {
  const { user, changePassword, logout } = useAuth();
  const { t, dir } = useI18n("auth");
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");
    if (newPassword.length < 6) {
      setError("كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("كلمتا المرور الجديدتان غير متطابقتين.");
      return;
    }
    setSubmitting(true);
    try {
      await changePassword(oldPassword, newPassword);
      setSuccess("تم تغيير كلمة المرور بنجاح.");
      setOldPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (requestError) {
      setError(requestError?.message || "تعذّر تغيير كلمة المرور.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell className="auth-ui-shell auth-ui-force-password" title={t("غيّر كلمة المرور")} subtitle={t("يلزم تغيير كلمة المرور قبل المتابعة إلى مساحة العمل.")}>
      <Panel className="auth-ui-card" dir={dir}>
        <div className="auth-ui-warning">
          <div className="auth-ui-button-row"><ShieldCheck size={17} aria-hidden="true" /><strong>{t("أمّن حسابك")}</strong></div>
          <p>{t("مسجّل الدخول باسم {username}. ستُلغى الجلسات الأخرى بعد هذا التغيير.", { username: user?.username || "" })}</p>
        </div>
        {error && <StatusNote tone="error">{t(error)}</StatusNote>}
        {success && <StatusNote tone="success">{t(success)}</StatusNote>}
        <form onSubmit={submit} className="ds-form-stack auth-ui-form" noValidate>
          <PasswordField id="force-old-password" testId="force-old-password" label="كلمة المرور الحالية" value={oldPassword} onChange={(event) => setOldPassword(event.target.value)} autoComplete="current-password" />
          <PasswordField id="force-new-password" testId="force-new-password" label="كلمة المرور الجديدة" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} autoComplete="new-password" />
          <PasswordField id="force-confirm-password" testId="force-confirm-password" label="تأكيد كلمة المرور الجديدة" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} autoComplete="new-password" />
          <ActionButton type="submit" loading={submitting} tone="primary" data-testid="force-password-submit" className="auth-ui-submit">
            {submitting ? t("جارٍ التحديث…") : t("تحديث كلمة المرور")}
          </ActionButton>
        </form>
        <button type="button" onClick={logout} className="auth-ui-footer" data-testid="force-password-logout">
          <LogOut size={15} aria-hidden="true" /> {t("تسجيل الخروج")}
        </button>
      </Panel>
    </AuthShell>
  );
}
