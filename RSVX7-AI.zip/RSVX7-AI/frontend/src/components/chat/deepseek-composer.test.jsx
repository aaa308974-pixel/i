import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";
import ChatInput from "./ChatInput";

const mockSetDeepThink = jest.fn();
const mockSetWebSearch = jest.fn();
const mockSetModel = jest.fn();
const mockSendMessage = jest.fn(() => true);
const mockRetrySave = jest.fn();
const mockProcessFile = jest.fn(() => Promise.resolve({ text: "", kind: "image", truncated: false }));
let mockChat;

jest.mock("@/context/ChatContext", () => ({ useChat: () => mockChat }));
jest.mock("@/context/SubscriptionContext", () => ({ useSubscription: () => ({ openRenewalModal: jest.fn() }) }));
jest.mock("@/lib/aiClient", () => ({ processFile: (...args) => mockProcessFile(...args) }));
jest.mock("@/components/design/Primitives", () => ({
  Panel: ({ children, ...props }) => <div {...props}>{children}</div>,
  StatusNote: ({ children, ...props }) => <div {...props}>{children}</div>,
}));
jest.mock("@/components/ui/tooltip", () => ({
  TooltipProvider: ({ children }) => <>{children}</>,
  Tooltip: ({ children }) => <>{children}</>,
  TooltipTrigger: ({ children }) => <>{children}</>,
  TooltipContent: ({ children }) => <span>{children}</span>,
}));
jest.mock("@/components/ui/dropdown-menu", () => {
  const React = require("react");
  const Root = ({ children }) => <div>{children}</div>;
  const Trigger = ({ children }) => <>{children}</>;
  const Content = ({ children, align: _align, sideOffset: _sideOffset, forceMount: _forceMount, ...props }) => <div {...props}>{children}</div>;
  const Item = ({ children, onClick, ...props }) => <button type="button" onClick={onClick} {...props}>{children}</button>;
  const Sub = ({ children }) => <div>{children}</div>;
  const SubTrigger = ({ children, ...props }) => <button type="button" {...props}>{children}</button>;
  const SubContent = ({ children, sideOffset: _sideOffset, ...props }) => <div {...props}>{children}</div>;
  return {
    DropdownMenu: Root,
    DropdownMenuTrigger: Trigger,
    DropdownMenuContent: Content,
    DropdownMenuItem: Item,
    DropdownMenuSub: Sub,
    DropdownMenuSubContent: SubContent,
    DropdownMenuSubTrigger: SubTrigger,
    DropdownMenuSeparator: () => null,
  };
});

function renderInput(overrides = {}, controller) {
  mockChat = {
    sendMessage: mockSendMessage,
    isStreaming: false,
    messagesLoading: false,
    saveErrors: [],
    retrySave: mockRetrySave,
    stop: jest.fn(),
    prefs: { modelId: "kaligpt", deepThink: false, webSearch: false, autoSuffix: { enabled: false, text: "" } },
    setModel: mockSetModel,
    activeChat: { messagesLoaded: true, darkMode: true },
    activateDarkMode: jest.fn(),
    deactivateDarkMode: jest.fn(),
    reasoningSupported: true,
    reasoningMandatory: false,
    setDeepThink: mockSetDeepThink,
    webSearchSupported: false,
    setWebSearch: mockSetWebSearch,
    ...overrides,
  };
  const node = document.createElement("div");
  document.body.appendChild(node);
  const root = createRoot(node);
  act(() => root.render(<ChatInput controller={controller} />));
  return { node, root };
}

function setTextareaValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
  setter.call(input, value);
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

beforeEach(() => {
  jest.clearAllMocks();
  global.IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  document.body.replaceChildren();
});

test("matches the composer contract and keeps unsupported search honest", () => {
  const { node } = renderInput();
  expect(node.querySelector('[data-testid="chat-input-container"]').className).toContain("deepseek-composer");
  expect(node.querySelector('[data-testid="deepthink-btn"]')).not.toBeNull();
  expect(node.querySelector('[data-testid="deepthink-btn"]').disabled).toBe(false);
  const search = node.querySelector('[data-testid="web-search-btn"]');
  expect(search.disabled).toBe(true);
  expect(search.getAttribute("title")).toContain("غير مهيأ");
  expect(node.querySelector('[data-testid="dark-mode-btn"]')).not.toBeNull();
  expect(node.querySelector('[data-testid="model-picker-btn"]')).toBeNull();
  expect(node.querySelector('[data-testid="attach-file-btn"]')).not.toBeNull();
});

test("connects DeepThink and supported web search to useChat setters", () => {
  const { node } = renderInput({ webSearchSupported: true });
  act(() => node.querySelector('[data-testid="deepthink-btn"]').click());
  act(() => node.querySelector('[data-testid="web-search-btn"]').click());
  expect(mockSetDeepThink).toHaveBeenCalledWith(true);
  expect(mockSetWebSearch).toHaveBeenCalledWith(true);
});

test("disables DeepThink only when the model does not support reasoning", () => {
  const { node } = renderInput({ reasoningSupported: false });
  expect(node.querySelector('[data-testid="deepthink-btn"]').disabled).toBe(true);
});

test("preserves Enter, Shift+Enter, and IME composition behavior", async () => {
  const { node } = renderInput();
  const input = node.querySelector('[data-testid="chat-input"]');
  act(() => {
    setTextareaValue(input, "  hello  ");
  });
  await act(async () => input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter" })));
  expect(mockSendMessage).toHaveBeenCalledWith("hello", []);

  mockSendMessage.mockClear();
  act(() => {
    setTextareaValue(input, "line");
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter", shiftKey: true }));
  });
  expect(mockSendMessage).not.toHaveBeenCalled();

  act(() => {
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter", isComposing: true }));
  });
  expect(mockSendMessage).not.toHaveBeenCalled();
});

test("keeps save retry and file test identifiers available", () => {
  const { node } = renderInput({ saveErrors: [{ key: "turn-1" }] });
  expect(node.querySelector('[data-testid="chat-save-error"]')).not.toBeNull();
  act(() => node.querySelector('[data-testid="retry-save-turn-1"]').click());
  expect(mockRetrySave).toHaveBeenCalledWith("turn-1");
  expect(node.querySelector('[data-testid="file-picker-input"]')).not.toBeNull();
});

test("Builder reuses native input, suffix and dark controls and retains rejected text", async () => {
  const send = jest.fn(async () => false), disable = jest.fn();
  const { node, root } = renderInput({prefs:{autoSuffix:{enabled:true,text:"Suffix"}}}, {sendMessage:send,deactivateDarkMode:disable});
  expect(node.querySelector('[data-testid="auto-suffix-preview"]').textContent).toContain("Suffix");
  act(() => node.querySelector('[data-testid="dark-mode-btn"]').click());
  expect(disable).toHaveBeenCalled();
  const input=node.querySelector('[data-testid="chat-input"]');
  act(() => setTextareaValue(input,"Keep my request"));
  await act(async()=>node.querySelector('[data-testid="send-btn"]').click());
  expect(send).toHaveBeenCalledWith("Keep my request",[]);
  expect(input.value).toBe("Keep my request");
  act(()=>node.querySelector('[data-testid="builder-mode-btn"]').click());
  expect(window.location.hash).toBe("#chat");
  await act(async()=>root.unmount());
});
