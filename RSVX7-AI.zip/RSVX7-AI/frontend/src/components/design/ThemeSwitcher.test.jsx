import React, { act } from "react";
import { createRoot } from "react-dom/client";
import ThemeSwitcher, { setTheme, THEME_KEY } from "./ThemeSwitcher";
import { setLanguage } from "@/i18n";
let node, root;
beforeEach(() => { global.IS_REACT_ACT_ENVIRONMENT = true; localStorage.clear(); setTheme("dark"); setLanguage("en"); node=document.createElement("div");document.body.appendChild(node);root=createRoot(node); });
afterEach(async () => { await act(async()=>root.unmount());node.remove();setTheme("dark");setLanguage("ar"); });
test("theme switch applies the root palette and persists without changing language", async () => {
  await act(async()=>root.render(<div><input defaultValue="keep draft" /><ThemeSwitcher /></div>));
  const input=node.querySelector("input"); const button=node.querySelector("button");
  expect(button.getAttribute("aria-label")).toBe("Switch to light theme");
  await act(async()=>button.click());
  expect(document.documentElement.dataset.theme).toBe("light");
  expect(document.documentElement.classList.contains("dark")).toBe(false);
  expect(localStorage.getItem(THEME_KEY)).toBe("light");
  expect(node.querySelector("input")).toBe(input);expect(input.value).toBe("keep draft");
  await act(async()=>button.click());
  expect(document.documentElement.dataset.theme).toBe("dark");
  expect(button.getAttribute("aria-label")).toBe("Switch to light theme");
});
test("storage update synchronizes the visible control",async()=>{
  await act(async()=>root.render(<ThemeSwitcher />));
  await act(async()=>{localStorage.setItem(THEME_KEY,"light");window.dispatchEvent(new StorageEvent("storage",{key:THEME_KEY,newValue:"light"}));});
  expect(node.querySelector("button").getAttribute("aria-pressed")).toBe("true");
  expect(document.documentElement.dataset.theme).toBe("light");
});
