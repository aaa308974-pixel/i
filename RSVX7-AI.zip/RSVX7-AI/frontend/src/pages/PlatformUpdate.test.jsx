import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import PlatformUpdate from './PlatformUpdate';
const mockFetch = jest.fn();
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ authFetch: mockFetch }) }));
jest.mock('@/components/ui/button', () => ({ Button: ({ variant, ...props }) => <button {...props} /> }));
let node, root;
const reply = value => ({ ok: true, json: async () => value });
beforeEach(() => { global.IS_REACT_ACT_ENVIRONMENT = true; mockFetch.mockReset(); node = document.createElement('div'); document.body.append(node); root = createRoot(node); });
afterEach(async () => { await act(async () => root.unmount()); node.remove(); });
test('unconfigured host disables update and shows setup file', async () => {
  mockFetch.mockResolvedValue(reply({configured:false}));
  await act(async () => root.render(<PlatformUpdate />));
  expect(node.querySelector('button').disabled).toBe(true);
  expect(node.textContent).toContain('OPERATIONS.txt');
});
test('button requests fixed update once then locks while pending', async () => {
  mockFetch.mockImplementation(async (path, options) => reply({ configured:true, repository:'owner/repo', branch:'main', status:options?'pending':'idle', stage:options?'queued':'ready' }));
  await act(async () => root.render(<PlatformUpdate />));
  await act(async () => node.querySelector('button').click());
  expect(node.querySelector('button').disabled).toBe(true);
  expect(mockFetch.mock.calls.find(([,options])=>options)?.[1]).toEqual({method:'POST',body:'{}'});
  expect(node.textContent).toContain('owner/repo');
});
