#!/usr/bin/env python3
"""Start the local Agent without requiring a system pip installation."""
from __future__ import annotations
import os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv-agent"
PYTHON = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def main():
    if not PYTHON.exists():
        try:
            subprocess.check_call([sys.executable, "-m", "venv", str(VENV)])
        except subprocess.CalledProcessError:
            raise SystemExit("Install python3-venv, then run agent/run_agent.py again.")
    try:
        subprocess.check_call([str(PYTHON), "-c", "import psutil, websocket"], stdout=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        subprocess.check_call([str(PYTHON), "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([str(PYTHON), "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")])
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT)
    subprocess.run([str(PYTHON), str(ROOT / "agent.py"), "--headless"], cwd=ROOT, env=env, check=False)


if __name__ == "__main__":
    main()
