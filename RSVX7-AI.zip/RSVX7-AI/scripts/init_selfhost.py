#!/usr/bin/env python3
"""Create a new VPS configuration once; existing databases/secrets stay in place."""
import argparse
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import sys
from urllib.parse import urlsplit

def prepare(target,settings):
    target=Path(target)
    if target.exists(): return False
    url=urlsplit(settings.get('siteUrl','http://localhost'))
    if url.scheme not in ('http','https') or not url.hostname or url.username or url.password or url.path not in ('','/') or url.query or url.fragment:
        raise ValueError('Use a plain HTTP/HTTPS site origin.')
    if url.port not in (None,80 if url.scheme=='http' else 443) or not re.fullmatch(r'[a-zA-Z0-9.-]{1,253}',url.hostname): raise ValueError('Invalid site hostname or port.')
    if url.scheme=='https':
        try: ipaddress.ip_address(url.hostname)
        except ValueError: pass
        else: raise ValueError('Automatic HTTPS requires a domain pointed at this server.')
    provider=settings.get('provider','openrouter')
    if provider not in ('openrouter','local'): raise ValueError('Invalid model provider.')
    model=settings.get('model') or ('qwen2.5-coder:7b' if provider=='local' else 'nousresearch/hermes-3-llama-3.1-405b')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}',model): raise ValueError('Invalid model name.')
    api_key=str(settings.get('providerKey',''))
    if any(c in api_key for c in ('\n','\r','\x00','"',"'",'$', '`')): raise ValueError('Invalid provider key.')
    values={
        'RSVX7_DATA_BACKEND':'mongo','RSVX7_STANDALONE':'true','RSVX7_RUNTIME_ENV':'production','DB_NAME':'rsvx7ai',
        'MONGO_INITDB_ROOT_USERNAME':'rsvx7','MONGO_INITDB_ROOT_PASSWORD':secrets.token_hex(24),
        'RSVX7_JWT_SECRET':secrets.token_hex(48),'OWNER_USERNAME':'admin-rsvx7','OWNER_INITIAL_PASSWORD':secrets.token_urlsafe(24),
        'COOKIE_SECURE':'true' if url.scheme=='https' else 'false','SITE_ADDRESS':url.hostname if url.scheme=='https' else ':80',
        'AI_PROVIDER':provider,'OPENROUTER_MODEL':model,
        'CORS_ORIGINS':url.scheme+'://'+url.hostname,'FILE_STORAGE_BACKEND':'gridfs',
        'VISION_MODEL':'','VISION_BASE_URL':'','VISION_API_KEY':'',
        'OPENROUTER_BASE_URL':'http://ollama:11434/v1' if provider=='local' else 'https://openrouter.ai/api/v1',
        'OPENROUTER_API_KEY':'local-ollama' if provider=='local' else api_key,'OPENROUTER_SITE_URL':url.scheme+'://'+url.hostname,
        'LOCAL_MODEL_NAME':model if provider=='local' else 'qwen2.5-coder:7b',
    }
    target.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as file:
        file.write('# Private deployment configuration. Keep this file and database volumes.\n')
        for name,value in values.items(): file.write(name+'='+value+'\n')
    return True

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--env-file',default='.env.selfhost');parser.add_argument('--settings-stdin',action='store_true');parser.add_argument('--site',default='http://localhost');parser.add_argument('--local-model')
    args=parser.parse_args()
    settings=json.load(sys.stdin) if args.settings_stdin else {'siteUrl':args.site,'provider':'local' if args.local_model else 'openrouter','model':args.local_model}
    created=prepare(args.env_file,settings)
    print('Deployment configuration created.' if created else 'Existing configuration preserved.')
if __name__=='__main__':main()
