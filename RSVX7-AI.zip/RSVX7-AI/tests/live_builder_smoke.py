"""Opt-in bounded live Builder smoke test. Synthetic input; credentials never saved.
Run: python -m tests.live_builder_smoke --live
Requires dev test dependencies. Uses real engine + real provider SDK, isolated in-memory records.
"""
import argparse, asyncio, copy, getpass, json, os, re, secrets, socket
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx, jwt, pytest, uvicorn
from fastapi import FastAPI
from openai import AsyncOpenAI
from tests.test_builder import setup, builder, ai_settings, auth, USER

async def main(key, model):
    patch = pytest.MonkeyPatch()
    db = setup.__wrapped__(patch)
    db.users.rows['alice']['role'] = 'admin'
    db.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id':'live-smoke','status':'running'}}
    async with httpx.AsyncClient(timeout=30) as catalog:
        reply = await catalog.get('https://openrouter.ai/api/v1/models'); reply.raise_for_status()
        selected = next((item for item in reply.json()['data'] if item['id']==model),None)
    if selected is None: raise RuntimeError('Requested smoke-test model is not in the provider catalog')
    settings = {'model':model,'key_configured':True,'context_length':selected['context_length'],
                'max_completion_tokens':4096,'supported_parameters':selected.get('supported_parameters',[])}
    prices = selected.get('pricing',{})
    price_in,price_out = float(prices['prompt']),float(prices['completion'])
    print('Live model:',model,flush=True)
    patch.setattr(builder,'current_settings',AsyncMock(return_value=settings))
    client = AsyncOpenAI(api_key=key,base_url='https://openrouter.ai/api/v1',max_retries=0,timeout=150)
    requests, ceiling = 0, 0.0
    async def create(**kwargs):
        nonlocal requests,ceiling
        # Conservative byte-based prompt upper bound + output cap. Stop before excess spend.
        estimate = sum(len(m['content'].encode())+20 for m in kwargs['messages'])*price_in + kwargs['max_tokens']*price_out
        if requests >= 12 or ceiling+estimate>0.75: raise RuntimeError('Live smoke-test budget reached')
        requests+=1;ceiling+=estimate
        role = re.search(r'DARKFORGE_AGENT:(\w+)',kwargs['messages'][0]['content'])
        print('Provider call',requests,role.group(1) if role else 'planning',flush=True)
        return await client.chat.completions.create(**kwargs)
    patch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    patch.setattr(ai_settings,'request_client',lambda value:value)
    listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen();api_port=listener.getsockname()[1]
    reserve=socket.socket();reserve.bind(('127.0.0.1',0));engine_port=reserve.getsockname()[1];reserve.close()
    app=FastAPI();app.include_router(builder.router)
    server=uvicorn.Server(uvicorn.Config(app,log_level='error',lifespan='off'))
    serving=asyncio.create_task(server.serve(sockets=[listener]))
    secret=secrets.token_hex(32)
    engine=await asyncio.create_subprocess_exec('node',str(Path(__file__).resolve().parents[1]/'builder/dist/service.mjs'),env={**os.environ,'BUILDER_ENGINE_SECRET':secret,'BUILDER_ENGINE_PORT':str(engine_port),'BUILDER_API_ORIGIN':f'http://127.0.0.1:{api_port}'},stdout=asyncio.subprocess.DEVNULL)
    try:
        async with httpx.AsyncClient(timeout=900) as local:
            base=f'http://127.0.0.1:{engine_port}'
            for _ in range(100):
                try:
                    if (await local.get(base+'/health',headers={'Authorization':'Bearer '+secret})).status_code==200: break
                except httpx.HTTPError: pass
                await asyncio.sleep(.05)
            ticket=jwt.encode({'sub':'alice','pid':'p_owned','job':'live-smoke','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
            proposal={'kind':'proposal','title':'Greeting','summary':'A tiny static Arabic greeting page','pages':[{'name':'Home','purpose':'Show greeting'}],
                      'features':['Display أهلاً وسهلاً as the main heading'],'design':'Readable centered Arabic heading on a light background','steps':['Implement static HTML and CSS only'],
                      'acceptanceChecks':['The Arabic heading أهلاً وسهلاً is visible.']}
            payload={'ticket':ticket,'mode':'build','files':{},'approvedPlan':proposal,'messages':[{'role':'user','content':'Build the approved tiny static Arabic greeting page. No JavaScript, forms, backend, external dependencies or images. Keep files small. This is a synthetic protocol smoke test.'}]}
            events=[]
            async with local.stream('POST',base+'/generate',headers={'Authorization':'Bearer '+secret},json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.strip(): continue
                    event=json.loads(line);events.append(event)
                    if event['type']=='error': print('ENGINE ERROR:',event.get('code'),event['message'],flush=True)
            result=next((event for event in events if event['type']=='files'),None)
            assert result and events[-1]['type']=='done','Live Builder did not finish'
            assert all(task['status']=='completed' for task in result['annotation']['tasks'])
            assert 'أهلاً وسهلاً' in result['files']['/home/project/index.html']['content']
            assert not result['annotation'].get('salvaged')
            print('PASS live architect → designer → coder → reviewer; files:',len(result['files']),'calls:',requests,'reserved USD upper bound:',round(ceiling,4),flush=True)
    finally:
        if engine.returncode is None: engine.terminate();await engine.wait()
        server.should_exit=True;await serving
        await client.close();patch.undo()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--live',action='store_true');parser.add_argument('--model',default='nousresearch/hermes-3-llama-3.1-405b');args=parser.parse_args()
    if not args.live: parser.error('Explicit --live is required; this test calls a paid provider')
    secret=os.environ.get('OPENROUTER_API_KEY') or getpass.getpass('OpenRouter test key (not saved): ')
    asyncio.run(main(secret,args.model))
