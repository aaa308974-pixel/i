import asyncio
import copy
import json
import os
import shlex
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from openai import APIStatusError, AsyncOpenAI

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'backend'))
from remote_control import ai_service
native_get_client = ai_service.get_client
from remote_control.autonomous import TOOLS, run_task

MODEL = 'cognitivecomputations/dolphin-mistral-24b-venice-edition'
MESSAGES = [{'role': 'system', 'content': 'Follow the task and read actual command results.'},
            {'role': 'user', 'content': 'Check disk space usage'}]


def cmd(command='df -h', stage='inspect'):
    return {'tool': 'run_command', 'arguments': {'command': command, 'stage': stage,
            'shell': 'auto', 'explanation': 'فحص النتيجة', 'timeout_seconds': 0}}


def finish(step=1):
    return {'tool': 'finish_task', 'arguments': {'status': 'success', 'summary': 'تم التنفيذ والتحقق.',
            'evidence': [{'step_id': step, 'finding': 'Observed successful verification output'}]}}


class CompatibilityTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.client_patch = patch.object(ai_service, "get_client", lambda: ai_service._client)
        self.client_patch.start()
        self.saved_client = ai_service._client
        self.saved_cache = ai_service._text_protocol_models.copy()
        ai_service._text_protocol_models.clear()
        self.env = patch.dict(os.environ, {'AI_EXECUTION_PROTOCOL': 'auto',
                             'OPENROUTER_BASE_URL': 'https://provider.test/api/v1'})
        self.env.start()
        self.model_patch = patch.object(ai_service, 'MODEL', MODEL)
        self.model_patch.start()
        self.requests, self.answers = [], []
        self.native_status = 404
        self.native_message = 'No endpoints found that support tool use. Try disabling "run_command".'
        self.native_completion = None
        self.transient_remaining = 0
        ai_service._client = AsyncOpenAI(api_key='test-only', base_url='https://provider.test/api/v1',
            max_retries=0, http_client=httpx.AsyncClient(transport=httpx.MockTransport(self.handle)))

    async def asyncTearDown(self):
        self.client_patch.stop()
        await ai_service._client.close()
        ai_service._client = self.saved_client
        ai_service._text_protocol_models.clear()
        ai_service._text_protocol_models.update(self.saved_cache)
        self.model_patch.stop()
        self.env.stop()

    def handle(self, request):
        body = json.loads(request.content)
        self.requests.append(copy.deepcopy(body))
        if self.transient_remaining:
            self.transient_remaining -= 1
            return httpx.Response(429, json={'error': {'message': 'Temporary rate limit', 'code': 429}})
        if 'tools' in body:
            if self.native_completion is None:
                return httpx.Response(self.native_status, json={'error': {
                    'message': self.native_message, 'code': self.native_status,
                    'metadata': {'failed_routing_step': 'Filter by Tool Compatibility'}}})
            message = copy.deepcopy(self.native_completion)
        else:
            answer = self.answers.pop(0)
            message = {'role': 'assistant', 'content': answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False)}
        return httpx.Response(200, json={'id': 'test-response', 'object': 'chat.completion',
            'created': 1, 'model': body['model'], 'choices': [{'index': 0, 'message': message,
            'finish_reason': 'tool_calls' if message.get('tool_calls') else 'stop'}]})

    async def test_native_404_falls_back_to_the_same_model_and_caches_compatibility(self):
        self.answers = [cmd(), finish()]
        first = await ai_service.request_task_turn(MESSAGES, TOOLS)
        second = await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(first['execution_protocol'], 'json')
        self.assertEqual(second['tool_calls'][0]['function']['name'], 'finish_task')
        self.assertEqual(len(self.requests), 3)
        self.assertTrue(all(r['model'] == MODEL for r in self.requests))
        self.assertTrue(all('max_tokens' not in r and 'max_completion_tokens' not in r for r in self.requests))
        self.assertIn('tools', self.requests[0])
        for request in self.requests[1:]:
            self.assertTrue(all(k not in request for k in ('tools', 'tool_choice', 'parallel_tool_calls', 'response_format', 'models')))
            self.assertTrue(all(set(m) == {'role', 'content'} for m in request['messages']))

    async def test_native_tool_models_keep_the_existing_native_path(self):
        self.native_completion = {'role': 'assistant', 'content': '', 'tool_calls': [{
            'id': 'native-call', 'type': 'function', 'function': {'name': 'run_command',
            'arguments': json.dumps(cmd()['arguments'])}}], 'reasoning_details': [{'type': 'reasoning.text', 'text': 'private'}]}
        result = await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(result['execution_protocol'], 'native')
        self.assertEqual(result['tool_calls'][0]['id'], 'native-call')
        self.assertIn('reasoning_details', result)
        self.assertEqual(len(self.requests), 1)

    async def test_provider_that_ignores_native_tools_gets_a_fresh_json_request(self):
        self.native_completion = {'role': 'assistant', 'content': 'Run this manually: echo never-execute'}
        self.answers = [cmd()]
        result = await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(result['tool_calls'][0]['function']['name'], 'run_command')
        self.assertEqual(len(self.requests), 2)
        self.assertNotIn('echo never-execute', json.dumps(self.requests[1]))

    async def test_explicit_json_mode_never_sends_native_tools(self):
        os.environ['AI_EXECUTION_PROTOCOL'] = 'json'
        self.answers = [cmd()]
        result = await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(result['execution_protocol'], 'json')
        self.assertNotIn('tools', self.requests[0])

    async def test_forced_native_mode_reports_the_provider_error(self):
        os.environ['AI_EXECUTION_PROTOCOL'] = 'native'
        with self.assertRaises(APIStatusError):
            await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(len(self.requests), 1)

    async def test_real_auth_credit_rate_limit_and_unknown_model_errors_are_not_masked(self):
        for status, message in [(401, 'Invalid API key'), (402, 'Insufficient credits'),
                                (429, 'Rate limit exceeded'), (500, 'Internal server error'),
                                (404, 'No endpoints found for this unknown model')]:
            self.native_status, self.native_message = status, message
            count = len(self.requests)
            with self.subTest(status=status), self.assertRaises(APIStatusError):
                await ai_service.request_task_turn(MESSAGES, TOOLS)
            self.assertEqual(len(self.requests), count + 1)
            self.assertFalse(ai_service._text_protocol_models)

    async def test_unsupported_tool_choice_also_uses_same_model_compatibility(self):
        self.native_status, self.native_message = 400, "tool_choice required is not supported by this model"
        self.answers = [cmd()]
        result = await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(result['execution_protocol'], 'json')
        self.assertTrue(all(r['model'] == MODEL for r in self.requests))

    async def test_capability_cache_is_scoped_to_the_configured_model(self):
        self.answers = [cmd(), cmd()]
        await ai_service.request_task_turn(MESSAGES, TOOLS)
        with patch.object(ai_service, 'MODEL', 'another-explicit-model'):
            await ai_service.request_task_turn(MESSAGES, TOOLS)
        self.assertEqual(sum('tools' in r for r in self.requests), 2)

    async def test_invalid_actions_are_corrected_before_any_execution(self):
        self.answers = ['```bash\necho should-never-run\n```', cmd('verify', 'verify'), finish()]
        observed, events = [], []
        async def execute(command, shell, timeout, on_output):
            observed.append(command)
            await on_output('ACTUAL verified result')
            return {'exit_code': 0, 'duration': 0.01}
        async def send(event): events.append(event)
        record = await run_task(MESSAGES[1:], 'Linux test target', ai_service.request_task_turn, execute, send)
        self.assertEqual(observed, ['verify'])
        self.assertTrue(record['verified'])
        self.assertIn('Action rejected; nothing was executed', self.requests[2]['messages'][0]['content'])
        self.assertTrue(all(r['model'] == MODEL for r in self.requests))

    async def test_many_invalid_json_actions_are_corrected_without_executing_text(self):
        self.answers = ['Manual command: echo unsafe', '{"command":"echo unsafe"}', '[{"tool":"run_command"}]'] * 4
        self.answers += [{'tool': 'finish_task', 'arguments': {'status': 'blocked', 'summary': 'Actual missing requirement', 'evidence': []}}]
        observed = []
        async def execute(*args): observed.append(args); return {'exit_code': 0}
        async def send(event): pass
        record = await run_task(MESSAGES[1:], 'test', ai_service.request_task_turn, execute, send)
        self.assertFalse(observed)
        self.assertEqual(record['status'], 'blocked')
        self.assertEqual(record['summary'], 'Actual missing requirement')
        self.assertEqual(len(self.requests), 14)

    async def test_transient_provider_errors_are_retried_without_replaying_commands(self):
        self.transient_remaining = 7
        self.answers = [cmd('verify', 'verify'), finish()]
        observed = []
        original_sleep = asyncio.sleep
        async def fast_sleep(delay): await original_sleep(0)
        async def execute(command, shell, timeout, on_output):
            observed.append(command)
            await on_output('Actual verification')
            return {'exit_code': 0, 'duration': 0.01}
        async def send(event): pass
        with patch('remote_control.autonomous.asyncio.sleep', fast_sleep):
            record = await run_task(MESSAGES[1:], 'test', ai_service.request_task_turn, execute, send)
        self.assertTrue(record['verified'])
        self.assertEqual(observed, ['verify'])
        self.assertEqual(len(self.requests), 10)

    async def test_manual_stop_interrupts_provider_retry_wait(self):
        self.transient_remaining = 100
        ready = asyncio.Event()
        async def execute(*args): self.fail('A command was executed during provider failure')
        async def send(event):
            if event['type'] == 'step': ready.set()
        task = asyncio.create_task(run_task(MESSAGES[1:], 'test', ai_service.request_task_turn, execute, send))
        await asyncio.wait_for(ready.wait(), 2)
        task.cancel()
        record = await asyncio.wait_for(task, 2)
        self.assertEqual(record['status'], 'cancelled')

    async def test_client_reuses_platform_provider_without_a_second_key(self):
        from remote_control.platform_model import client
        with patch.dict(os.environ, {'OPENROUTER_API_KEY':'unused-secondary-key'}, clear=True):
            self.assertIs(native_get_client(), client)
            self.assertIs(native_get_client().chat.completions, client)

    async def test_full_same_model_loop_reads_real_errors_repairs_and_requires_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            filename = shlex.quote(str(Path(directory) / 'result.txt'))
            commands = [f"test ! -e {filename} && printf 'file absent\\n'",
                        "printf 'Missing dependency XYZ\\n' >&2; exit 17",
                        f"printf 'ready\\n' > {filename}; printf 'repair completed\\n'",
                        f"test \"$(cat {filename})\" = ready && printf 'verified contents: '; cat {filename}"]
            self.answers = [cmd(commands[0], 'inspect'), cmd(commands[1], 'execute'),
                            cmd(commands[2], 'repair'), finish(3), cmd(commands[3], 'verify'), finish(4)]
            events, observed = [], []
            async def execute(command, shell, timeout, on_output):
                observed.append(command)
                process = await asyncio.create_subprocess_exec('bash', '-c', command,
                    stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
                data = await process.stdout.read()
                await on_output(data.decode())
                return {'exit_code': await process.wait(), 'duration': 0.01}
            async def send(event): events.append(copy.deepcopy(event))
            record = await run_task([{'role': 'user', 'content': 'أنشئ الملف المطلوب بمحتوى ready وتحقق منه'}],
                'OS=Linux. Real isolated test directory.', ai_service.request_task_turn, execute, send)
            self.assertEqual(observed, commands)
            self.assertEqual((Path(directory) / 'result.txt').read_text(), 'ready\n')
        self.assertEqual(record['status'], 'success')
        self.assertTrue(record['verified'])
        self.assertEqual(record['execution_protocol'], 'json')
        self.assertEqual(record['steps'][1]['exit_code'], 17)
        self.assertEqual(record['evidence'][0]['step_id'], 4)
        wire = json.dumps(self.requests, ensure_ascii=False)
        self.assertIn('Missing dependency XYZ', wire)
        self.assertIn('repair completed', wire)
        self.assertIn('verified contents: ready', wire)
        self.assertIn('Completion rejected', wire)
        self.assertTrue(all(r['model'] == MODEL for r in self.requests))
        self.assertEqual(sum('tools' in r for r in self.requests), 1)
        self.assertTrue(all(not e['needs_confirmation'] for e in events if e['type'] == 'command'))
