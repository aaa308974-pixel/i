import asyncio
import copy
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'backend'))
from remote_control.autonomous import run_task, history_content


def call(name, **arguments):
    return {'content': '', 'tool_calls': [{'id': 'call-' + str(call.counter), 'type': 'function',
        'function': {'name': name, 'arguments': json.dumps(arguments)}}]}
call.counter = 0


def command(text, stage='execute'):
    call.counter += 1
    return call('run_command', command=text, explanation=text, stage=stage, shell='auto')


def finish(status='success', step=1):
    call.counter += 1
    return call('finish_task', status=status, summary='Verified requested result' if status == 'success' else 'Concrete blocker',
                evidence=[{'step_id': step, 'finding': 'Actual version and executable path checked'}] if status == 'success' else [])


class Model:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.inputs = []
    async def __call__(self, messages, tools):
        self.inputs.append(copy.deepcopy(messages))
        return next(self.responses)


class AutonomousTests(unittest.IsolatedAsyncioTestCase):
    async def run_scenario(self, responses, results=None):
        model = Model(responses)
        events, executed = [], []
        async def send(event): events.append(copy.deepcopy(event))
        results = iter(results or [])
        async def execute(cmd, shell, timeout, on_output):
            executed.append(cmd)
            result = next(results, {'exit_code': 0, 'duration': 0.1, 'output': 'ACTUAL ' + cmd})
            await on_output(result.get('output', ''))
            return result
        record = await run_task([{'role': 'user', 'content': 'Install the requested program'}], 'test machine',
                                model, execute, send)
        return record, events, executed, model

    async def test_continues_after_success_and_reads_every_result(self):
        record, events, executed, model = await self.run_scenario([
            command('inspect', 'inspect'), command('install'), command('version', 'verify'), finish(step=3)])
        self.assertEqual(executed, ['inspect', 'install', 'version'])
        self.assertEqual(record['status'], 'success')
        self.assertTrue(record['verified'])
        for index, cmd in enumerate(executed):
            feedback = [m for m in model.inputs[index + 1] if m['role'] == 'tool'][-1]
            self.assertIn('ACTUAL ' + cmd, feedback['content'])
        self.assertTrue(all(not e['needs_confirmation'] for e in events if e['type'] == 'command'))
        self.assertIn('ACTUAL install', history_content(record))

    async def test_failed_step_is_repaired_and_original_goal_verified(self):
        record, events, executed, model = await self.run_scenario([
            command('install'), command('fix-dependency', 'repair'), command('install-again'),
            command('check-program', 'verify'), finish(step=4)], [
            {'exit_code': 1, 'output': 'Missing dependency XYZ', 'duration': 0.1},
            {'exit_code': 0, 'output': 'Dependency ready', 'duration': 0.1}])
        self.assertEqual(record['status'], 'success')
        self.assertEqual(record['steps'][0]['status'], 'failed')
        self.assertIn('Missing dependency XYZ', model.inputs[1][-1]['content'])
        self.assertEqual(executed[-1], 'check-program')
        self.assertTrue(any(e.get('stage') == 'repair' for e in events))

    async def test_cannot_claim_success_before_verification(self):
        record, events, executed, model = await self.run_scenario([
            command('install'), finish(step=1), command('verify-version', 'verify'), finish(step=2)])
        self.assertEqual(executed, ['install', 'verify-version'])
        self.assertIn('Completion rejected', model.inputs[2][-1]['content'])
        self.assertEqual(record['evidence'][0]['step_id'], 2)

    async def test_verification_must_follow_the_last_change(self):
        record, events, executed, model = await self.run_scenario([
            command('check-before', 'verify'), command('change'), finish(step=1),
            command('check-after', 'verify'), finish(step=3)])
        self.assertTrue(record['verified'])
        self.assertEqual(record['evidence'][0]['step_id'], 3)
        self.assertIn('Completion rejected', model.inputs[3][-1]['content'])

    async def test_failed_verification_never_becomes_success(self):
        record, events, executed, model = await self.run_scenario([
            command('check', 'verify'), finish(step=1), finish('blocked')],
            [{'exit_code': 1, 'output': 'Executable missing', 'duration': 0.1}])
        self.assertEqual(record['status'], 'blocked')
        self.assertFalse(record['verified'])

    async def test_repeated_failure_has_no_attempt_limit_and_every_result_is_read(self):
        record, events, executed, model = await self.run_scenario([
            *[command('retry') for _ in range(8)], command('verify', 'verify'), finish(step=9)],
            [{'exit_code': 1, 'output': 'Temporary dependency error', 'duration': 0.1}] * 8)
        self.assertEqual(executed, ['retry'] * 8 + ['verify'])
        self.assertIn('Temporary dependency error', model.inputs[8][-1]['content'])
        self.assertEqual(record['status'], 'success')

    async def test_multiple_calls_wait_for_first_observation(self):
        response = command('first')
        response['tool_calls'] += command('premature')['tool_calls']
        record, events, executed, model = await self.run_scenario([
            response, command('verify', 'verify'), finish(step=2)])
        self.assertEqual(executed, ['first', 'verify'])
        self.assertEqual(len([m for m in model.inputs[1] if m['role'] == 'tool']), 2)

    async def test_markdown_is_never_executed_as_a_command(self):
        record, events, executed, model = await self.run_scenario([
            *[{'content': 'Run this: echo manual', 'tool_calls': []}] * 12, finish('blocked')])
        self.assertFalse(executed)
        self.assertEqual(record['status'], 'blocked')

    async def test_timeout_result_reaches_model(self):
        record, events, executed, model = await self.run_scenario([command('slow'), finish('blocked')],
            [{'exit_code': 124, 'timed_out': True, 'output': 'Timed out', 'duration': 1}])
        self.assertTrue(record['steps'][0]['timed_out'])
        self.assertTrue(json.loads(model.inputs[1][-1]['content'])['timed_out'])
        self.assertEqual(record['status'], 'blocked')

    async def test_cancellation_keeps_completed_steps_and_stops_execution(self):
        entered = asyncio.Event()
        async def execute(cmd, shell, timeout, on_output):
            entered.set()
            await on_output('partial real output')
            await asyncio.Event().wait()
        async def send(event): pass
        record = {}
        task = asyncio.create_task(run_task([{'role': 'user', 'content': 'نزلي برنامج'}], 'test',
                                           Model([command('waiting')]), execute, send, record=record))
        await entered.wait()
        task.cancel()
        result = await task
        self.assertEqual(result['status'], 'cancelled')
        self.assertEqual(result['language'], 'ar')
        self.assertEqual(result['steps'][0]['status'], 'cancelled')
        self.assertIn('partial real output', result['steps'][0]['output'])

    async def test_task_exceeds_former_step_and_model_turn_limits_even_with_old_settings(self):
        responses = [command('step-' + str(i)) for i in range(150)]
        responses += [command('verify', 'verify'), finish(step=151)]
        with patch.dict('os.environ', {'AI_MAX_STEPS': '1', 'AI_TASK_TIMEOUT_SECONDS': '1'}):
            record, events, executed, model = await self.run_scenario(responses)
        self.assertEqual(len(executed), 151)
        self.assertEqual(record['status'], 'success')
        self.assertTrue(all(e['timeout_seconds'] == 0 for e in events if e['type'] == 'command'))

    async def test_invalid_actions_are_corrected_without_a_turn_or_retry_limit(self):
        invalid = {'content': 'Needs correction', 'tool_calls': []}
        record, events, executed, model = await self.run_scenario([
            *[copy.deepcopy(invalid) for _ in range(145)], command('verify', 'verify'), finish(step=1)])
        self.assertTrue(record['verified'])
        self.assertEqual(executed, ['verify'])
        self.assertEqual(len(model.inputs), 147)

    async def test_infinite_invalid_model_is_manually_cancellable(self):
        ready = asyncio.Event()
        count = 0
        async def request(messages, tools):
            nonlocal count
            count += 1
            if count >= 20: ready.set()
            return {'content': 'Not a valid action yet', 'tool_calls': []}
        async def execute(*args): self.fail('Invalid prose was executed')
        async def send(event): pass
        task = asyncio.create_task(run_task([{'role': 'user', 'content': 'Continue until stopped'}],
                                            'test', request, execute, send))
        await asyncio.wait_for(ready.wait(), 2)
        task.cancel()
        record = await asyncio.wait_for(task, 2)
        self.assertEqual(record['status'], 'cancelled')
        self.assertGreaterEqual(count, 20)

    async def test_stale_model_deadline_is_ignored_and_large_commands_are_preserved(self):
        requested = command('X' * 50000, 'verify')
        args = json.loads(requested['tool_calls'][0]['function']['arguments'])
        args['timeout_seconds'] = 1
        requested['tool_calls'][0]['function']['arguments'] = json.dumps(args)
        record, events, executed, model = await self.run_scenario([requested, finish(step=1)])
        self.assertEqual(executed, ['X' * 50000])
        self.assertEqual(next(e['timeout_seconds'] for e in events if e['type'] == 'command'), 0)
        self.assertTrue(record['verified'])

    async def test_output_context_is_bounded_without_losing_tail(self):
        record, events, executed, model = await self.run_scenario([
            command('huge', 'verify'), finish(step=1)],
            [{'exit_code': 0, 'duration': 0.1, 'output': 'START-' + 'X' * 50000 + '-END'}])
        data = json.loads(model.inputs[1][-1]['content'])['output']
        self.assertLessEqual(len(data), 8000)
        self.assertTrue(data.startswith('START-'))
        self.assertTrue(data.endswith('-END'))
        self.assertEqual(record['steps'][0]['output'], 'START-' + 'X' * 50000 + '-END')
