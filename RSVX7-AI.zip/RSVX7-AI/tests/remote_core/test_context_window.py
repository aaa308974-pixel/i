import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'backend'))
from remote_control.context_window import fit_context, size


def make_context(rounds=120, parallel=1):
    messages=[{'role':'system','content':'ROOT SYSTEM RULES'}, {'role':'system','content':'OS=Linux'},
              {'role':'user','content':'ORIGINAL REQUEST: finish all requested operations'}]
    for index in range(rounds):
        calls=[{'id':f'{index}-{i}','type':'function','function':{'name':'run_command',
                'arguments':json.dumps({'command':f'step-{index}-{i}','stage':'execute'})}} for i in range(parallel)]
        messages.append({'role':'assistant','content':'','tool_calls':calls})
        for call in reversed(calls):
            messages.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps({
                'step_id':index+1,'command':call['function']['arguments'],'exit_code':0,
                'output':f'ACTUAL-{index}-'+'X'*1500})})
    return messages


def test_small_context_is_unchanged():
    original=make_context(1)
    assert fit_context(original) is original


def test_long_context_keeps_goal_recent_results_and_complete_native_tool_groups():
    original=make_context(parallel=3)
    wire=fit_context(original, char_budget=16000)
    assert size(wire)<16000
    assert wire[:3]==original[:3]
    assert 'ROLLING EXECUTION MEMORY' in wire[3]['content']
    assert 'ACTUAL-119-' in wire[-1]['content']
    pending=set()
    for message in wire:
        if message.get('tool_calls'):
            pending.update(c['id'] for c in message['tool_calls'])
        elif message['role']=='tool':
            assert message['tool_call_id'] in pending
            pending.remove(message['tool_call_id'])
    assert not pending
    assert len(original)==483


def test_older_conversation_is_compacted_without_losing_current_request_or_root_rules():
    messages=[{'role':'system','content':'ROOT RULES'}, {'role':'system','content':'CONNECTED TARGET'}]
    messages += [{'role':'assistant' if i%2 else 'user','content':str(i)+'X'*2000} for i in range(30)]
    messages += [{'role':'user','content':'CURRENT ORIGINAL REQUEST'}]
    wire=fit_context(messages,char_budget=16000)
    assert wire[:2]==messages[:2]
    assert wire[-1]==messages[-1]
    assert size(wire)<16000
