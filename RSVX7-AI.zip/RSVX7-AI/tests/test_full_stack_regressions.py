"""Opt-in end-to-end test: its own process, private port, temporary Mongo database."""
import os
import json
import hmac
import hashlib
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import secrets
import socket
import subprocess
import tempfile
import time
from pathlib import Path

import pytest
import requests
from pymongo import MongoClient

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def local_catalog():
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path != '/v1/models':
                self.send_error(404)
                return
            content = json.dumps({'data': [{'id': 'fixture/local-model', 'context_length': 8192}]}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        def log_message(self, *args):
            pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield 'http://127.0.0.1:' + str(server.server_port) + '/v1'
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


@pytest.mark.skipif(os.environ.get("RUN_E2E") != "1", reason="Separate temporary runtime is opt-in")
def test_real_runtime_auth_workspace_model_and_upload(local_catalog):
    name = "rsvx7ai_test_e2e_" + secrets.token_hex(6)
    password = secrets.token_urlsafe(20)
    new_password = secrets.token_urlsafe(20)
    env = os.environ.copy()
    env.update(MONGO_URL="mongodb://127.0.0.1:27017", DB_NAME=name,
               JWT_SECRET="short-platform-alias", RSVX7_JWT_SECRET=secrets.token_hex(32),
               RSVX7_RUNTIME_ENV="production", OWNER_USERNAME="e2e_owner",
               OWNER_INITIAL_PASSWORD=password, COOKIE_SECURE="false",
               DEEPSEEK_API_KEY="",
               FILE_STORAGE_BACKEND="gridfs",
               OPENROUTER_MODEL="fixture/local-model", OPENROUTER_BASE_URL=local_catalog,
               OPENROUTER_API_KEY="", VISION_MODEL="", VISION_API_KEY="",
               AI_PROVIDER="openrouter", RSVX7_STANDALONE="true")
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        engine_port = sock.getsockname()[1]
    env.update(PORT=str(port), BUILDER_ENGINE_PORT=str(engine_port), PATH=str(ROOT / '.venv/bin') + os.pathsep + env['PATH'])
    mongo = MongoClient(env["MONGO_URL"], serverSelectionTimeoutMS=3000)
    assert name.startswith("rsvx7ai_test_e2e_")
    with tempfile.TemporaryDirectory(prefix="rsvx7ai-e2e-") as temporary:
        env["OWNER_CREDENTIALS_FILE"] = str(Path(temporary) / "credentials.md")
        log_path = Path(temporary) / "server.log"
        with log_path.open("w") as log:
            process = subprocess.Popen([str(ROOT / ".venv/bin/python"), str(ROOT / "scripts/run_services.py")], cwd=ROOT, env=env, stdout=log, stderr=log)
        try:
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise AssertionError("Temporary server exited before readiness; inspect startup code")
                try:
                    if requests.get(base + "/readyz", timeout=1).status_code == 200:
                        break
                except requests.RequestException:
                    pass
                time.sleep(0.2)
            else:
                raise AssertionError("Temporary test server did not become ready")
            engine_secret = hmac.new(env['RSVX7_JWT_SECRET'].encode(), b'rsvx7-builder-engine-v1', hashlib.sha256).hexdigest()
            assert requests.get(f'http://127.0.0.1:{engine_port}/health', headers={'Authorization': 'Bearer ' + engine_secret}, timeout=3).status_code == 200
            assert requests.get(f'http://127.0.0.1:{engine_port}/health', timeout=3).status_code == 401
            assert requests.get(base + '/api/settings/public', timeout=3).json()['telegram_required'] is False
            session = requests.Session()
            login = session.post(base + "/api/auth/login", json={"username": "e2e_owner", "password": password}, timeout=10)
            assert login.status_code == 200
            old_token = login.json()["token"]
            session.headers["Authorization"] = "Bearer " + old_token
            assert session.get(base + "/api/auth/me", timeout=5).json()["must_change_password"] is True
            assert session.get(base + "/api/admin/ai-settings", timeout=5).status_code == 403
            rotated = session.post(base + "/api/auth/change-password", json={"old_password": password, "new_password": new_password}, timeout=10)
            assert rotated.status_code == 200
            token = rotated.json().get("token")
            if not token:
                relogin = session.post(base + "/api/auth/login", json={"username": "e2e_owner", "password": new_password}, timeout=10)
                assert relogin.status_code == 200
                token = relogin.json()["token"]
            session.headers["Authorization"] = "Bearer " + token
            assert requests.get(base + "/api/auth/me", headers={"Authorization": "Bearer " + old_token}, timeout=5).status_code == 401
            owner = session.get(base + "/api/auth/me", timeout=5).json()
            assert owner["must_change_password"] is False
            settings = session.get(base + "/api/admin/ai-settings", timeout=5)
            assert settings.status_code == 200
            assert settings.json()["model"] == env["OPENROUTER_MODEL"]
            assert "api_key" not in settings.json()
            saved = session.put(base + "/api/admin/ai-settings", json={"model": env["OPENROUTER_MODEL"]}, timeout=30)
            assert saved.status_code == 200
            assert mongo[name].settings.find_one({"_id": "ai"})["model"] == env["OPENROUTER_MODEL"]
            project = session.post(base + "/api/workspace/projects", json={"name": "Integration project"}, timeout=5)
            assert project.status_code in (200, 201)
            pid = project.json()["_id"]
            note = session.post(base + f"/api/workspace/projects/{pid}/notes", json={"content": "Persistence test"}, timeout=5)
            assert note.status_code in (200, 201)
            assert session.get(base + f"/api/workspace/projects/{pid}/notes", timeout=5).json()
            upload = session.post(base + "/api/files/process", files={"file": ("sample.txt", b"hello file extraction", "text/plain")}, timeout=10)
            assert upload.status_code == 200
            assert upload.json()["text"] == "hello file extraction"
            attachment = session.post(base + f"/api/workspace/projects/{pid}/files", files={"file": ("persistent.txt", b"gridfs attachment", "text/plain")}, timeout=15)
            assert attachment.status_code == 200
            fid = attachment.json()["_id"]
            assert attachment.json()["storage_path"].startswith("gridfs:")
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).content == b"gridfs attachment"
            assert session.post(base + "/api/chat/stream", json={"messages": [{"role": "system", "content": "client override"}]}, timeout=5).status_code == 422
            guest = requests.Session()
            signup = guest.post(base + "/api/auth/register", json={"username": "e2e_guest", "password": secrets.token_urlsafe(20)}, timeout=10)
            assert signup.status_code == 200
            guest.headers["Authorization"] = "Bearer " + signup.json()["token"]
            assert guest.get(base + "/api/admin/ai-settings", timeout=5).status_code == 403
            assert guest.get(base + f"/api/workspace/projects/{pid}", timeout=5).status_code == 404
            assert guest.get(base + f"/api/workspace/files/{fid}/download", timeout=5).status_code == 404
            # A globally seen Telegram ID alone must never prove ownership.
            mongo[name].tg_seen.insert_one({"_id": 99123456, "username": "another_telegram_user"})
            assert guest.post(base + "/api/auth/telegram/verify-by-id", json={"telegram_id": 99123456}, timeout=5).status_code in (400, 403, 409)
            assert session.get(base + "/api/billing/usage?limit=9999999", timeout=5).status_code == 422
            assert session.delete(base + f"/api/workspace/projects/{pid}", timeout=5).status_code == 200
            assert mongo[name].notes.count_documents({"project_id": pid}) == 0
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).status_code == 404
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            mongo.drop_database(name)
            mongo.close()
