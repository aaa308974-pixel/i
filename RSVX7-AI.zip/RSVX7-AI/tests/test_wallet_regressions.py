"""Wallet regression tests; never point these tests at preview/production Mongo.

The environment is selected before backend imports so auth.py cannot load a real
connection. Each test explicitly patches every module to a dedicated test database.
"""
from __future__ import annotations

import asyncio
import os
import sys
from contextlib import contextmanager

import pytest
from fastapi import HTTPException
from starlette.requests import Request
from motor.motor_asyncio import AsyncIOMotorClient

os.environ["MONGO_URL"] = "mongodb://127.0.0.1:27017"
os.environ["DB_NAME"] = "rsvx7ai_test_wallet"
os.environ["JWT_SECRET"] = "wallet-regression-test-secret"
os.environ["CORS_ORIGINS"] = "http://localhost"
os.environ["COOKIE_SECURE"] = "false"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

import auth  # noqa: E402
import coupons  # noqa: E402
import referrals  # noqa: E402
import tokens  # noqa: E402


TEST_LOOP = asyncio.new_event_loop()


def run(awaitable):
    return TEST_LOOP.run_until_complete(awaitable)


def run_gather(*awaitables):
    async def gather_all():
        return await asyncio.gather(*awaitables, return_exceptions=True)
    return run(gather_all())


def request():
    return Request({
        "type": "http", "method": "POST", "path": "/api/coupons/redeem",
        "headers": [], "query_string": b"", "client": ("127.0.0.1", 1234),
        "server": ("127.0.0.1", 27018),
    })


@pytest.fixture(autouse=True)
def clean_test_db(monkeypatch):
    client = AsyncIOMotorClient("mongodb://127.0.0.1:27017", io_loop=TEST_LOOP)
    test_database = client["rsvx7ai_test_wallet"]
    for module in (auth, coupons, referrals, tokens):
        monkeypatch.setattr(module, "db", test_database)
    async def clean():
        for name in ("users", "token_usage_history", "coupons", "redemptions", "referral_codes", "settings"):
            await auth.db[name].delete_many({})
        await coupons.ensure_indexes()

    run(clean())

    async def no_telegram(_text):
        return False

    monkeypatch.setattr(coupons, "tg_send", no_telegram)
    yield
    run(clean())
    client.close()


def test_charge_is_conditional_race_and_history_failure_compensates(monkeypatch):
    run(auth.db.users.insert_one({
        "_id": "u1", "token_balance": 20,
        "total_used_tokens": 0, "total_input_tokens": 0, "total_output_tokens": 0,
    }))

    async def charge():
        return await tokens.charge_user(
            "u1", prompt_tokens=8, completion_tokens=0, model="test"
        )

    results = run_gather(charge(), charge())
    assert sum(not isinstance(result, Exception) for result in results) == 1
    assert sum(isinstance(result, tokens.InsufficientTokensError) for result in results) == 1
    user = run(auth.db.users.find_one({"_id": "u1"}))
    assert user["token_balance"] == 8
    assert run(auth.db.token_usage_history.count_documents({"user_id": "u1"})) == 1

    run(auth.db.token_usage_history.insert_one({"_id": "u_fixed-history", "user_id": "other"}))
    monkeypatch.setattr(tokens.secrets, "token_urlsafe", lambda _n: "fixed-history")
    with pytest.raises(Exception):
        run(tokens.charge_user("u1", prompt_tokens=2, completion_tokens=0, model="test"))
    restored = run(auth.db.users.find_one({"_id": "u1"}))
    assert restored["token_balance"] == 8
    assert restored["total_used_tokens"] == 12
    assert restored["total_input_tokens"] == 8


def test_charge_optional_idempotency_marker_does_not_double_debit():
    run(auth.db.users.insert_one({"_id": "u2", "token_balance": 20}))
    first = run(tokens.charge_user(
        "u2", prompt_tokens=4, completion_tokens=0, idempotency_key="turn-1"
    ))
    second = run(tokens.charge_user(
        "u2", prompt_tokens=4, completion_tokens=0, idempotency_key="turn-1"
    ))
    assert first["_id"] == second["_id"]
    user = run(auth.db.users.find_one({"_id": "u2"}))
    assert user["token_balance"] == 14
    assert run(auth.db.token_usage_history.count_documents({"user_id": "u2"})) == 1


def test_coupon_race_is_idempotent_and_missing_user_compensates():
    run(auth.db.users.insert_one({"_id": "coupon-user", "username": "cu", "token_balance": 0}))
    run(auth.db.coupons.insert_one({
        "_id": "RACE", "tokens": 10, "max_uses": 1, "used_count": 0,
        "enabled": True, "repeat_allowed": False,
    }))
    body = coupons.RedeemBody(code="race")
    user = {"_id": "coupon-user", "username": "cu"}
    results = run_gather(
        coupons.redeem_coupon(body, request(), user),
        coupons.redeem_coupon(body, request(), user),
    )
    assert all(not isinstance(result, Exception) for result in results)
    saved_user = run(auth.db.users.find_one({"_id": "coupon-user"}))
    saved_coupon = run(auth.db.coupons.find_one({"_id": "RACE"}))
    assert saved_user["token_balance"] == 10
    assert saved_coupon["used_count"] == 1
    assert run(auth.db.redemptions.count_documents({"code": "RACE"})) == 1

    run(auth.db.coupons.insert_one({
        "_id": "MISSING", "tokens": 25, "max_uses": 1, "used_count": 0,
        "enabled": True, "repeat_allowed": False,
    }))
    with pytest.raises(HTTPException) as exc:
        run(coupons.redeem_coupon(coupons.RedeemBody(code="missing"), request(), {"_id": "gone"}))
    assert exc.value.status_code == 404
    missing_coupon = run(auth.db.coupons.find_one({"_id": "MISSING"}))
    assert missing_coupon["used_count"] == 0
    assert not missing_coupon.get("reservation_keys")
    assert run(auth.db.redemptions.count_documents({"code": "MISSING"})) == 0


def test_coupon_repeat_request_key_is_credit_idempotent():
    run(auth.db.users.insert_one({"_id": "repeat-user", "token_balance": 0}))
    run(auth.db.coupons.insert_one({
        "_id": "REPEAT", "tokens": 7, "max_uses": 0, "used_count": 0,
        "enabled": True, "repeat_allowed": True,
    }))
    body = coupons.RedeemBody(code="repeat", idempotency_key="request-1")
    user = {"_id": "repeat-user", "username": "ru"}
    first = run(coupons.redeem_coupon(body, request(), user))
    second = run(coupons.redeem_coupon(body, request(), user))
    assert first["tokens"] == second["tokens"] == 7
    saved_user = run(auth.db.users.find_one({"_id": "repeat-user"}))
    assert saved_user["token_balance"] == 7
    assert run(auth.db.redemptions.count_documents({"code": "REPEAT"})) == 1


def test_referral_two_party_markers_and_pending_retry():
    run(auth.db.users.insert_many([
        {"_id": "referrer", "token_balance": 0},
        {"_id": "invitee", "token_balance": 0, "referred_by": "referrer", "referral_pending": True},
    ]))
    results = run_gather(
        referrals.finalize_referral("invitee"),
        referrals.finalize_referral("invitee"),
    )
    assert all(not isinstance(result, Exception) for result in results)
    referrer = run(auth.db.users.find_one({"_id": "referrer"}))
    invitee = run(auth.db.users.find_one({"_id": "invitee"}))
    assert referrer["token_balance"] == referrals.REFERRER_BONUS
    assert referrer["referral_count"] == 1
    assert invitee["token_balance"] == referrals.INVITEE_BONUS
    assert invitee["referral_pending"] is False

    run(auth.db.users.insert_one({
        "_id": "retry-invitee", "token_balance": 0,
        "referred_by": "late-referrer", "referral_pending": True,
    }))
    pending = run(referrals.finalize_referral("retry-invitee"))
    assert pending["pending"] is True
    partial = run(auth.db.users.find_one({"_id": "retry-invitee"}))
    assert partial["referral_pending"] is True
    assert partial["token_balance"] == referrals.INVITEE_BONUS
    run(auth.db.users.insert_one({"_id": "late-referrer", "token_balance": 0}))
    done = run(referrals.finalize_referral("retry-invitee"))
    assert done["completed"] is True
    late = run(auth.db.users.find_one({"_id": "late-referrer"}))
    assert late["token_balance"] == referrals.REFERRER_BONUS


def test_referral_code_is_single_per_user_under_race():
    run(auth.db.users.insert_one({"_id": "code-user"}))
    results = run_gather(*[
        referrals.ensure_referral_code("code-user") for _ in range(8)
    ])
    assert len(set(results)) == 1
    assert run(auth.db.referral_codes.count_documents({"user_id": "code-user"})) == 1


def test_nonrepeat_coupon_ignores_different_client_retry_keys():
    run(auth.db.users.insert_one({"_id": "nonrepeat-user", "token_balance": 0}))
    run(auth.db.coupons.insert_one({"_id": "SINGLE", "enabled": True, "tokens": 7,
                                  "max_uses": 0, "used_count": 0, "repeat_allowed": False}))
    results = run_gather(*(coupons.redeem_coupon(
        coupons.RedeemBody(code="SINGLE", idempotency_key=f"retry-{i}"), request(), {"_id": "nonrepeat-user"}) for i in range(8)))
    assert all(isinstance(result, dict) and result["ok"] for result in results)
    assert run(auth.db.users.find_one({"_id": "nonrepeat-user"}))["token_balance"] == 7
    assert run(auth.db.coupons.find_one({"_id": "SINGLE"}))["used_count"] == 1
    assert run(auth.db.redemptions.count_documents({"code": "SINGLE"})) == 1
